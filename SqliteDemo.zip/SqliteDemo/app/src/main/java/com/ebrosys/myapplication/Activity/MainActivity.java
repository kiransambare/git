package com.ebrosys.myapplication.Activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import com.ebrosys.myapplication.Databases.DbHandler;
import com.ebrosys.myapplication.R;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    private  DbHandler mDbHandler;
    private ArrayList<HashMap<String, String>> mArrayListUser;
    private ListView mListViewUser;
    private ListAdapter mAdapterUser;
    private MenuItem mMenuItemDone,mMenuItemCancel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mDbHandler = new DbHandler(this);
        mArrayListUser= mDbHandler.GetUsers();
        mListViewUser= (ListView) findViewById(R.id.listViewUser);
        mAdapterUser = new SimpleAdapter(MainActivity.this, mArrayListUser, R.layout.list_row,new String[]{"name"}, new int[]{R.id.name});
        mListViewUser.setAdapter(mAdapterUser);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main1, menu);
        mMenuItemDone = menu.findItem(R.id.itemDone).setVisible(false);
        mMenuItemCancel = menu.findItem(R.id.itemCancel).setVisible(false);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.itemPlus:
                Intent intent = new Intent(MainActivity.this, AddItemActivity.class);
                startActivity(intent);
                finish();
                break;



            default:
        }
        return true;



    }

    @Override
    public void onBackPressed() {


                AlertDialog.Builder builder=new AlertDialog.Builder(this);
                builder.setTitle("Do You Want to exit?").setCancelable(true).setPositiveButton("yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        finish();
                    }
                }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                }).show();

    }

}
