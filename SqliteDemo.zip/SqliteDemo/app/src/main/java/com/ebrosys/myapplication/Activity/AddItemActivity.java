package com.ebrosys.myapplication.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.ebrosys.myapplication.Databases.DbHandler;
import com.ebrosys.myapplication.R;

public class AddItemActivity extends AppCompatActivity {
   private EditText mEdtName;
    private MenuItem mMenuItem;
    private Intent mIntent;
    private DbHandler mDbHandler;
    private String mstrUsername;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);
        mEdtName = (EditText)findViewById(R.id.edtName);


    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main1, menu);
        mMenuItem = menu.findItem(R.id.itemPlus).setVisible(false);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.itemDone:

                mstrUsername = mEdtName.getText().toString()+"\n";
                mDbHandler = new DbHandler(AddItemActivity.this);
                mDbHandler.insertUserDetails(mstrUsername);
                mIntent = new Intent(AddItemActivity.this,MainActivity.class);
                startActivity(mIntent);
                finish();
                Toast.makeText(getApplicationContext(), "Details Inserted Successfully",Toast.LENGTH_SHORT).show();
                break;

            case R.id.itemCancel:

                Intent intent=new Intent(AddItemActivity.this,MainActivity.class);
                startActivity(intent);
                finish();
            default:
        }
        return true;



    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent=new Intent(AddItemActivity.this,MainActivity.class);
        startActivity(intent);
        finish();
    }
}
